advancement revoke @s only jkbw:hurt/any
tellraw @s[tag=jkbw_invisible, scores={jkbw.Player.DamageType.now=2..}] [{"storage": "jk:bw", "nbt": "txt.print.becuz_be_attack", "color": "yellow"}, {"translate": "effect.minecraft.invisibility", "color": "white"}, {"storage": "jk:bw", "nbt": "txt.print.no_effect_now"}]
effect clear @s[scores={jkbw.Player.DamageType.now=2..}] invisibility

tellraw @s[nbt={active_effects: [{id: "minecraft:resistance", amplifier: 9b}]}] [{"storage": "jk:bw", "nbt": "txt.print.becuz_be_attack", "color": "yellow"}, {"storage": "jk:bw", "nbt": "txt.item.shop.the_mirror.name", "color": "white"}, {"storage": "jk:bw", "nbt": "txt.print.no_effect_now"}]
effect clear @s resistance
