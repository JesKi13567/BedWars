# 切换 - 我的末影箱
scoreboard players set @s jkbw.Player.Page -1
function jkbw:play/shop/gui/chest/player/global

# 记录物品
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill0"]}
data modify entity @e[type=item, tag=jkbw_finalkill0, limit=1] Item set from entity @s EnderItems[{Slot: 0b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill1"]}
data modify entity @e[type=item, tag=jkbw_finalkill1, limit=1] Item set from entity @s EnderItems[{Slot: 1b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill2"]}
data modify entity @e[type=item, tag=jkbw_finalkill2, limit=1] Item set from entity @s EnderItems[{Slot: 2b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill3"]}
data modify entity @e[type=item, tag=jkbw_finalkill3, limit=1] Item set from entity @s EnderItems[{Slot: 3b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill4"]}
data modify entity @e[type=item, tag=jkbw_finalkill4, limit=1] Item set from entity @s EnderItems[{Slot: 4b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill5"]}
data modify entity @e[type=item, tag=jkbw_finalkill5, limit=1] Item set from entity @s EnderItems[{Slot: 5b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill6"]}
data modify entity @e[type=item, tag=jkbw_finalkill6, limit=1] Item set from entity @s EnderItems[{Slot: 6b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill7"]}
data modify entity @e[type=item, tag=jkbw_finalkill7, limit=1] Item set from entity @s EnderItems[{Slot: 7b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill8"]}
data modify entity @e[type=item, tag=jkbw_finalkill8, limit=1] Item set from entity @s EnderItems[{Slot: 8b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill9"]}
data modify entity @e[type=item, tag=jkbw_finalkill9, limit=1] Item set from entity @s EnderItems[{Slot: 9b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill10"]}
data modify entity @e[type=item, tag=jkbw_finalkill10, limit=1] Item set from entity @s EnderItems[{Slot: 10b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill11"]}
data modify entity @e[type=item, tag=jkbw_finalkill11, limit=1] Item set from entity @s EnderItems[{Slot: 11b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill12"]}
data modify entity @e[type=item, tag=jkbw_finalkill12, limit=1] Item set from entity @s EnderItems[{Slot: 12b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill13"]}
data modify entity @e[type=item, tag=jkbw_finalkill13, limit=1] Item set from entity @s EnderItems[{Slot: 13b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill14"]}
data modify entity @e[type=item, tag=jkbw_finalkill14, limit=1] Item set from entity @s EnderItems[{Slot: 14b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill15"]}
data modify entity @e[type=item, tag=jkbw_finalkill15, limit=1] Item set from entity @s EnderItems[{Slot: 15b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill16"]}
data modify entity @e[type=item, tag=jkbw_finalkill16, limit=1] Item set from entity @s EnderItems[{Slot: 16b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill17"]}
data modify entity @e[type=item, tag=jkbw_finalkill17, limit=1] Item set from entity @s EnderItems[{Slot: 17b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill18"]}
data modify entity @e[type=item, tag=jkbw_finalkill18, limit=1] Item set from entity @s EnderItems[{Slot: 18b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill19"]}
data modify entity @e[type=item, tag=jkbw_finalkill19, limit=1] Item set from entity @s EnderItems[{Slot: 19b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill20"]}
data modify entity @e[type=item, tag=jkbw_finalkill20, limit=1] Item set from entity @s EnderItems[{Slot: 20b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill21"]}
data modify entity @e[type=item, tag=jkbw_finalkill21, limit=1] Item set from entity @s EnderItems[{Slot: 21b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill22"]}
data modify entity @e[type=item, tag=jkbw_finalkill22, limit=1] Item set from entity @s EnderItems[{Slot: 22b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill23"]}
data modify entity @e[type=item, tag=jkbw_finalkill23, limit=1] Item set from entity @s EnderItems[{Slot: 23b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill24"]}
data modify entity @e[type=item, tag=jkbw_finalkill24, limit=1] Item set from entity @s EnderItems[{Slot: 24b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill25"]}
data modify entity @e[type=item, tag=jkbw_finalkill25, limit=1] Item set from entity @s EnderItems[{Slot: 25b}]
summon item 10110222 1 10110222 {Item: {id: "black_wool", count: 1b}, Tags: ["jkbw_finalkill_item", "jkbw_finalkill26"]}
data modify entity @e[type=item, tag=jkbw_finalkill26, limit=1] Item set from entity @s EnderItems[{Slot: 26b}]

# 清理
kill @e[type=item, tag=jkbw_finalkill_item, nbt={Item: {id: "minecraft:black_wool"}}]
clear @s

# 传送到所在团队资源点
execute as @s[team=jkbw.red] run tp @e[type=item, tag=jkbw_finalkill_item] @e[type=text_display, tag=jkbw_res_red, limit=1]
execute as @s[team=jkbw.blue] run tp @e[type=item, tag=jkbw_finalkill_item] @e[type=text_display, tag=jkbw_res_blue, limit=1]
execute as @s[team=jkbw.green] run tp @e[type=item, tag=jkbw_finalkill_item] @e[type=text_display, tag=jkbw_res_green, limit=1]
execute as @s[team=jkbw.yellow] run tp @e[type=item, tag=jkbw_finalkill_item] @e[type=text_display, tag=jkbw_res_yellow, limit=1]
execute as @s[team=jkbw.cyan] run tp @e[type=item, tag=jkbw_finalkill_item] @e[type=text_display, tag=jkbw_res_cyan, limit=1]
execute as @s[team=jkbw.white] run tp @e[type=item, tag=jkbw_finalkill_item] @e[type=text_display, tag=jkbw_res_white, limit=1]
execute as @s[team=jkbw.pink] run tp @e[type=item, tag=jkbw_finalkill_item] @e[type=text_display, tag=jkbw_res_pink, limit=1]
execute as @s[team=jkbw.gray] run tp @e[type=item, tag=jkbw_finalkill_item] @e[type=text_display, tag=jkbw_res_gray, limit=1]
