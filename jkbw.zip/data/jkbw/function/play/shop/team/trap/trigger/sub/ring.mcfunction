scoreboard players remove @s jkbw.mem 1
playsound entity.experience_orb.pickup player @a[distance=..20] ~ ~ ~ 16 1.6 1
kill @s[scores={jkbw.mem=..0}]
